from ultralytics import YOLO
import torch

# Check if GPU is available
if torch.cuda.is_available():
    print("Using GPU for training")
    device = 'cuda'  # Set device to GPU
else:
    print("GPU not available, using CPU for training")
    device = 'cpu'  # Use CPU if GPU is not available

# Load the YOLO model
model = YOLO('yolov8n.yaml')  # Make sure the model config file is correct

# Train the model
model.train(data=r'C:\Users\User\Downloads\InnovationProject\data.yaml', epochs=1, device="0")
